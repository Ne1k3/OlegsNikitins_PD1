/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author Antec AMD
 */
public class Admin extends User {
 public Admin(String name, String surname, String username, String password) {
        super(name, surname, username, password, "admin");
    }

 @Override
    public boolean canDeleteUser(User target) {
        return true; 
    }

 @Override
    public boolean canViewUser(User target) {
        return true; 
    }

 @Override
    public boolean canViewResults(User target) {
        return true; 
    }

 @Override
    public boolean canViewComments(User target) {
        return true; 
    }

 @Override
    public boolean canGrantTestAccess(User target) {
        return target.isStudent(); // Может выдавать тест ученикам
    }

 @Override
    public boolean canRevokeTestAccess(User target) {
        return target.isStudent(); // Может запрещать тест ученикам
    }
}
