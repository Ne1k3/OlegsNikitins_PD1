/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author Antec AMD
 */
public class Teacher extends User {
public Teacher(String name, String surname, String username, String password) {
        super(name, surname, username, password, "skolotajs");
    }

    
@Override
    public boolean canDeleteUser(User target) {
        return target.isStudent();
    }

    // Можно просматривать только учеников
@Override
    public boolean canViewUser(User target) {
        return target.isStudent();
    }

    // Можно просматривать результаты только учеников
@Override
    public boolean canViewResults(User target) {
        return target.isStudent();
    }

    // Можно просматривать комментарии только учеников
@Override
    public boolean canViewComments(User target) {
        return target.isStudent();
    }
@Override
     public boolean canGrantTestAccess(User target) {
        return target.isStudent(); 
    }

@Override
    public boolean canRevokeTestAccess(User target) {
        return target.isStudent();
}
}

