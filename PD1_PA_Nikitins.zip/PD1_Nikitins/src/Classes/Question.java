/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.util.List;

/**
 *
 * @author Antec AMD
 */
public class Question {
 private String text;
    private List<String> answers;
    private int correctIndex;

    public Question(String text, List<String> answers, int correctIndex) {
        this.text = text;
        this.answers = answers;
        this.correctIndex = correctIndex;
    }

    public String getText() { return text; }
    public List<String> getAnswers() { return answers; }
    public int getCorrectIndex() { return correctIndex; }

    public boolean isCorrect(int selectedIndex) {
        return selectedIndex == correctIndex;
    }
}
