/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Antec AMD
 */
public class UserRepository {
 private static final String FILE_NAME = "LoginPassword.txt";

    public static List<User> getAllUsers() throws IOException {
        List<User> users = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5) {
                    String name = parts[0];
                    String surname = parts[1];
                    String username = parts[2];
                    String password = parts[3];
                    String role = parts[4];
                    switch (role) {
                        case "skolens" -> users.add(new Student(name, surname, username, password));
                        case "skolotajs" -> users.add(new Teacher(name, surname, username, password));
                        case "admin" -> users.add(new Admin(name, surname, username, password));
                        default -> users.add(new User(name, surname, username, password, role));
                    }
                }
            }
        }
        return users;
    }

    public static void saveUser(User user) throws IOException {
        try (FileWriter writer = new FileWriter(FILE_NAME, true)) {
            writer.write(user.toFileFormat() + System.lineSeparator());
        }
    }

    public static void deleteUser(String username, String password) throws IOException {
        File inputFile = new File(FILE_NAME);
        File tempFile = new File("LoginPassword_temp.txt");

        try (
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4 && parts[2].equals(username) && parts[3].equals(password)) {
                    continue; // пропускаем строку — удаление
                }
                writer.write(line + System.lineSeparator());
            }
        }

        inputFile.delete();
        tempFile.renameTo(inputFile);
    }
}
