
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static org.junit.Assert.*;
import java.io.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author olegs
 */


public class UserServiceTest {

    private File tempFile;

    @Before
    public void setUp() throws IOException {
        tempFile = File.createTempFile("LoginPassword", ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            writer.write("Gunars,Gravitis,Alien,123,skolens\n");
            writer.write("Anna,Berzina,Teacher1,pass456,skolotajs\n");
        }
    }

    @After
    public void tearDown() {
        if (tempFile != null && tempFile.exists()) {
            tempFile.delete();
        }
    }

    // ==== Тесты ====

    @Test
    public void testIsFieldEmpty() {
        assertTrue(UserService.isFieldEmpty("text", "", "another"));
        assertFalse(UserService.isFieldEmpty("name", "surname", "pass"));
    }

    @Test
    public void testIsValidLength() {
        assertTrue(UserService.isValidLength("Lietotajs", 3, 20));
        assertFalse(UserService.isValidLength("ab", 3, 20));
    }

    @Test
    public void testPasswordsMatch() {
        assertTrue(UserService.passwordsMatch("parole123", "parole123"));
        assertFalse(UserService.passwordsMatch("123", "321"));
    }

    @Test
    public void testUserExists() throws IOException {
        assertTrue(UserService.userExists("Alien", tempFile));
        assertTrue(UserService.userExists("Teacher1", tempFile));
        assertFalse(UserService.userExists("Unknown", tempFile));
    }

    @Test
    public void testLoginCorrect() throws IOException {
        assertTrue(UserService.loginCorrect("Alien", "123", tempFile));
        assertFalse(UserService.loginCorrect("Alien", "wrongpass", tempFile));
    }

    @Test
    public void testRegisterNewUser() throws IOException {
        assertTrue(UserService.registerUser("Test", "User", "NewUser", "pass789", "skolens", tempFile));
        assertTrue(UserService.userExists("NewUser", tempFile));
    }

    @Test
    public void testRegisterDuplicateUser() throws IOException {
        // Alien уже есть в начальных данных
        assertFalse(UserService.registerUser("Someone", "Else", "Alien", "anotherPass", "skolens", tempFile));
    }

    @Test
    public void testDeleteExistingStudent() throws IOException {
        assertTrue(UserService.deleteUser("Alien", "skolens", tempFile));
        assertFalse(UserService.userExists("Alien", tempFile));
    }

    @Test
    public void testDeleteNonExistingUser() throws IOException {
        assertFalse(UserService.deleteUser("GhostUser", "skolens", tempFile));
    }
}

// ==== Класс с логикой (в том же файле) ====

class UserService {

    public static boolean isFieldEmpty(String... fields) {
        for (String field : fields) {
            if (field == null || field.trim().isEmpty()) return true;
        }
        return false;
    }

    public static boolean isValidLength(String input, int min, int max) {
        return input != null && input.length() >= min && input.length() <= max;
    }

    public static boolean passwordsMatch(String pass1, String pass2) {
        return pass1 != null && pass1.equals(pass2);
    }

    public static boolean userExists(String username, File file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[2].trim().equals(username.trim())) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean loginCorrect(String username, String password, File file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4 &&
                        parts[2].trim().equals(username) &&
                        parts[3].trim().equals(password)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean registerUser(String name, String surname, String username, String password, String role, File file) throws IOException {
        if (userExists(username, file)) return false;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(name + "," + surname + "," + username + "," + password + "," + role + System.lineSeparator());
        }
        return true;
    }

    public static boolean deleteUser(String username, String role, File file) throws IOException {
        File tempFile = new File(file.getAbsolutePath() + ".tmp");
        boolean deleted = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5) {
                    String login = parts[2].trim();
                    String userRole = parts[4].trim();
                    if (login.equals(username) && userRole.equals(role)) {
                        deleted = true;
                        continue;
                    }
                }
                writer.write(line + System.lineSeparator());
            }
        }

        if (deleted) {
            if (!file.delete() || !tempFile.renameTo(file)) {
                return false;
            }
        } else {
            tempFile.delete();
        }
        return deleted;
    }
}


