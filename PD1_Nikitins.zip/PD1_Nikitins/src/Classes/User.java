/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author Antec AMD
 */
public class User {
 protected String name;
    protected String surname;
    protected String username;
    protected String password;
    protected String role;

    public User(String name, String surname, String username, String password, String role) {
        this.name = name;
        this.surname = surname;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    
    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    // --- Роль-помощники ---
    public boolean isStudent() {
        return "skolens".equalsIgnoreCase(role);
    }

    public boolean isTeacher() {
        return "skolotajs".equalsIgnoreCase(role);
    }

    public boolean isAdmin() {
        return "admin".equalsIgnoreCase(role);
    }

    public boolean isExaminer() {
        return "eksamenators".equalsIgnoreCase(role);
    }

 
    public boolean canDeleteUser(User target) {
        return false;
    }

    public boolean canViewUser(User target) {
        return false;
    }

    public boolean canViewResults(User target) {
        return false;
    }

    public boolean canViewComments(User target) {
        return false;
    }

    public boolean canGrantTestAccess(User target) {
        return false;
    }

    public boolean canRevokeTestAccess(User target) {
        return false;
    }

    public boolean canViewAdminPassword() {
        return false;
    }


    public String toFileFormat() {
        return name + "," + surname + "," + username + "," + password + "," + role;
    }
}

